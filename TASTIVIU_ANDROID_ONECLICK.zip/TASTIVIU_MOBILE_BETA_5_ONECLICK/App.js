import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import * as Notifications from 'expo-notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { WebView } from 'react-native-webview';
import { TASTIVIU_HTML } from './src/tastiviuHtml';

const API_BASE = process.env.EXPO_PUBLIC_API_BASE_URL || '';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

const C = {
  ink: '#143C3A',
  teal: '#0F5E59',
  coral: '#E26B55',
  cream: '#F8F5EE',
  paper: '#FFFFFF',
  sage: '#E7F1EC',
  muted: '#6B7A78',
  line: '#D9E4DE',
  danger: '#B44336',
  warning: '#A86D18',
};

const COPY = {
  ca: {
    app: 'TASTIVIU', scan: 'Escàner', map: 'Mapa', barcode: 'Codi', label: 'Etiqueta',
    scanBarcode: 'Apunta al codi de barres', scanLabel: 'Fotografia la llista d’ingredients',
    takePhoto: 'Llegir etiqueta', gallery: 'Triar fotografia', again: 'Tornar a escanejar',
    product: 'Producte detectat', ingredients: 'Ingredients', allergens: 'Al·lèrgens declarats', traces: 'Traces declarades',
    analyze: 'Analitzar amb TASTIVIU', verify: 'Revisa sempre l’etiqueta actual de l’envàs.',
    mapTitle: 'Mapa TASTIVIU', mapHelp: 'Xinxetes útils de la comunitat i establiments que vols recordar.',
    addPin: 'Afegir xinxeta', useLocation: 'La meva ubicació', name: 'Nom de l’establiment',
    detail: 'Què hi has trobat de útil?', save: 'Publicar xinxeta', cancel: 'Cancel·lar',
    rating: 'Puntuació TASTIVIU', openGoogle: 'Buscar a Google Maps',
    safetyTitle: 'Abans de començar', safetyBody: 'TASTIVIU és una eina d’orientació. No garanteix que un aliment sigui segur. Les receptes, ingredients, línies de producció i advertiments poden canviar. Revisa sempre l’etiqueta de l’envàs actual i segueix el teu pla mèdic. L’OCR, les traduccions, les bases de dades i les aportacions de la comunitat poden contenir errors o estar desactualitzades.',
    safetyCheck: 'Ho he llegit i entenc que TASTIVIU no substitueix l’etiqueta, el fabricant ni el meu equip sanitari.',
    enter: 'Entrar a TASTIVIU', needCamera: 'Cal donar permís de càmera per escanejar.',
    ocrUnavailable: 'L’OCR natiu no està disponible en aquesta compilació. Utilitza una development build / APK / iOS build de TASTIVIU.',
    ocrWorking: 'Llegint etiqueta…', noText: 'No s’ha pogut extreure prou text. Torna a fer la foto amb bona llum.',
    noProduct: 'No s’ha trobat aquest codi a Open Food Facts.', noMapKey: 'Per al binari Android final cal configurar una clau de Google Maps. En Expo Go es pot provar el mapa sense configuració addicional.',
    pins: 'xinxetes', localData: 'Les xinxetes es guarden al dispositiu i també s’envien a la versió TASTIVIU integrada.',
  },
  es: {
    app: 'TASTIVIU', scan: 'Escáner', map: 'Mapa', barcode: 'Código', label: 'Etiqueta',
    scanBarcode: 'Apunta al código de barras', scanLabel: 'Fotografía la lista de ingredientes',
    takePhoto: 'Leer etiqueta', gallery: 'Elegir fotografía', again: 'Volver a escanear',
    product: 'Producto detectado', ingredients: 'Ingredientes', allergens: 'Alérgenos declarados', traces: 'Trazas declaradas',
    analyze: 'Analizar con TASTIVIU', verify: 'Revisa siempre la etiqueta actual del envase.',
    mapTitle: 'Mapa TASTIVIU', mapHelp: 'Chinchetas útiles de la comunidad y establecimientos que quieras recordar.',
    addPin: 'Añadir chincheta', useLocation: 'Mi ubicación', name: 'Nombre del establecimiento',
    detail: '¿Qué has encontrado de útil?', save: 'Publicar chincheta', cancel: 'Cancelar',
    rating: 'Puntuación TASTIVIU', openGoogle: 'Buscar en Google Maps',
    safetyTitle: 'Antes de empezar', safetyBody: 'TASTIVIU es una herramienta de orientación. No garantiza que un alimento sea seguro. Las recetas, ingredientes, líneas de producción y avisos pueden cambiar. Revisa siempre la etiqueta del envase actual y sigue tu plan médico. El OCR, las traducciones, las bases de datos y las aportaciones de la comunidad pueden contener errores o estar desactualizadas.',
    safetyCheck: 'Lo he leído y entiendo que TASTIVIU no sustituye la etiqueta, el fabricante ni a mi equipo sanitario.',
    enter: 'Entrar en TASTIVIU', needCamera: 'Hay que dar permiso de cámara para escanear.',
    ocrUnavailable: 'El OCR nativo no está disponible en esta compilación. Utiliza una development build / APK / iOS build de TASTIVIU.',
    ocrWorking: 'Leyendo etiqueta…', noText: 'No se ha podido extraer suficiente texto. Repite la foto con buena luz.',
    noProduct: 'No se ha encontrado este código en Open Food Facts.', noMapKey: 'Para el binario Android final hay que configurar una clave de Google Maps. En Expo Go el mapa se puede probar sin configuración adicional.',
    pins: 'chinchetas', localData: 'Las chinchetas se guardan en el dispositivo y también se envían a la versión TASTIVIU integrada.',
  },
  eu: {
    app: 'TASTIVIU', scan: 'Eskanerra', map: 'Mapa', barcode: 'Kodea', label: 'Etiketa',
    scanBarcode: 'Jarri barra-kodea kameraren aurrean', scanLabel: 'Atera osagaien zerrendaren argazkia',
    takePhoto: 'Irakurri etiketa', gallery: 'Aukeratu argazkia', again: 'Berriz eskaneatu',
    product: 'Detektatutako produktua', ingredients: 'Osagaiak', allergens: 'Adierazitako alergenoak', traces: 'Adierazitako aztarnak',
    analyze: 'Aztertu TASTIVIUrekin', verify: 'Egiaztatu beti uneko ontziaren etiketa.',
    mapTitle: 'TASTIVIU mapa', mapHelp: 'Komunitatearen xinxeta erabilgarriak eta gogoratu nahi dituzun establezimenduak.',
    addPin: 'Gehitu xinxeta', useLocation: 'Nire kokapena', name: 'Establezimenduaren izena', detail: 'Zer aurkitu duzu erabilgarria?',
    save: 'Argitaratu xinxeta', cancel: 'Utzi', rating: 'TASTIVIU puntuazioa', openGoogle: 'Bilatu Google Maps-en',
    safetyTitle: 'Hasi aurretik', safetyBody: 'TASTIVIU orientazio-tresna bat da. Ez du elikagai bat segurua dela bermatzen. Errezetak, osagaiak, ekoizpen-lerroak eta oharrak alda daitezke. Egiaztatu beti uneko ontziaren etiketa eta jarraitu zure mediku-plana. OCRak, itzulpenek, datu-baseek eta komunitatearen ekarpenek akatsak izan ditzakete edo zaharkituta egon.',
    safetyCheck: 'Irakurri dut eta ulertzen dut TASTIVIUk ez duela etiketa, fabrikatzailea edo nire osasun-taldea ordezkatzen.', enter: 'Sartu TASTIVIUn',
    needCamera: 'Kameraren baimena behar da eskaneatzeko.', ocrUnavailable: 'OCR natiboa ez dago erabilgarri build honetan. Erabili TASTIVIUren development build / APK / iOS build.',
    ocrWorking: 'Etiketa irakurtzen…', noText: 'Ezin izan da testu nahikorik atera. Egin beste argazki bat argi onarekin.', noProduct: 'Kode hau ez da Open Food Facts-en aurkitu.',
    noMapKey: 'Android binario finalerako Google Maps gakoa konfiguratu behar da. Expo Go-n mapa konfigurazio gehigarririk gabe probatu daiteke.', pins: 'xinxeta', localData: 'Xinxetak gailuan gordetzen dira eta TASTIVIU integratura ere bidaltzen dira.',
  },
  en: {
    app: 'TASTIVIU', scan: 'Scanner', map: 'Map', barcode: 'Barcode', label: 'Label',
    scanBarcode: 'Point at the barcode', scanLabel: 'Photograph the ingredients list', takePhoto: 'Read label', gallery: 'Choose photo', again: 'Scan again',
    product: 'Product detected', ingredients: 'Ingredients', allergens: 'Declared allergens', traces: 'Declared traces', analyze: 'Analyse with TASTIVIU', verify: 'Always check the current package label.',
    mapTitle: 'TASTIVIU map', mapHelp: 'Useful community pins and places you want to remember.', addPin: 'Add pin', useLocation: 'My location', name: 'Venue name', detail: 'What useful thing did you find?', save: 'Publish pin', cancel: 'Cancel', rating: 'TASTIVIU score', openGoogle: 'Search Google Maps',
    safetyTitle: 'Before you start', safetyBody: 'TASTIVIU is an orientation tool. It does not guarantee that a food is safe. Recipes, ingredients, production lines and warnings can change. Always check the current package label and follow your medical plan. OCR, translations, databases and community contributions may contain errors or be out of date.', safetyCheck: 'I have read this and understand that TASTIVIU does not replace the label, manufacturer or my healthcare team.', enter: 'Enter TASTIVIU',
    needCamera: 'Camera permission is required to scan.', ocrUnavailable: 'Native OCR is not available in this build. Use a TASTIVIU development build / APK / iOS build.', ocrWorking: 'Reading label…', noText: 'Not enough text could be extracted. Take another photo in good light.', noProduct: 'This barcode was not found in Open Food Facts.', noMapKey: 'The final Android binary needs a Google Maps key. In Expo Go the map can be tested without extra configuration.', pins: 'pins', localData: 'Pins are stored on this device and also sent to the integrated TASTIVIU version.',
  },
  fr: {
    app: 'TASTIVIU', scan: 'Scanner', map: 'Carte', barcode: 'Code-barres', label: 'Étiquette',
    scanBarcode: 'Visez le code-barres', scanLabel: 'Photographiez la liste des ingrédients', takePhoto: 'Lire l’étiquette', gallery: 'Choisir une photo', again: 'Scanner à nouveau', product: 'Produit détecté', ingredients: 'Ingrédients', allergens: 'Allergènes déclarés', traces: 'Traces déclarées', analyze: 'Analyser avec TASTIVIU', verify: 'Vérifiez toujours l’étiquette actuelle du paquet.',
    mapTitle: 'Carte TASTIVIU', mapHelp: 'Repères utiles de la communauté et établissements à retenir.', addPin: 'Ajouter un repère', useLocation: 'Ma position', name: 'Nom de l’établissement', detail: 'Qu’avez-vous trouvé d’utile ?', save: 'Publier', cancel: 'Annuler', rating: 'Note TASTIVIU', openGoogle: 'Rechercher dans Google Maps',
    safetyTitle: 'Avant de commencer', safetyBody: 'TASTIVIU est un outil d’orientation. Il ne garantit pas qu’un aliment est sûr. Les recettes, ingrédients, lignes de production et avertissements peuvent changer. Vérifiez toujours l’étiquette du paquet actuel et suivez votre plan médical. L’OCR, les traductions, les bases de données et les contributions communautaires peuvent contenir des erreurs ou être obsolètes.', safetyCheck: 'J’ai lu et je comprends que TASTIVIU ne remplace ni l’étiquette, ni le fabricant, ni mon équipe soignante.', enter: 'Entrer dans TASTIVIU',
    needCamera: 'L’autorisation de la caméra est nécessaire pour scanner.', ocrUnavailable: 'L’OCR natif n’est pas disponible dans cette compilation. Utilisez une development build / APK / build iOS de TASTIVIU.', ocrWorking: 'Lecture de l’étiquette…', noText: 'Le texte n’a pas pu être extrait correctement. Reprenez la photo avec un bon éclairage.', noProduct: 'Ce code n’a pas été trouvé dans Open Food Facts.', noMapKey: 'Le binaire Android final nécessite une clé Google Maps. Dans Expo Go, la carte peut être testée sans configuration supplémentaire.', pins: 'repères', localData: 'Les repères sont enregistrés sur l’appareil et envoyés aussi à la version TASTIVIU intégrée.',
  },
};

function slug(s = '') {
  return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

function chooseProductName(p, code) {
  return p?.product_name_es || p?.product_name_ca || p?.product_name || p?.product_name_en || code;
}
function chooseIngredients(p) {
  return p?.ingredients_text_es || p?.ingredients_text_ca || p?.ingredients_text || p?.ingredients_text_en || '';
}
function tagLabel(tags = []) {
  return tags.map((x) => String(x).replace(/^[a-z]{2}:/, '').replace(/-/g, ' ')).join(', ');
}

function scoreForPlace(place, ratings = []) {
  const key = slug(place.name);
  const rs = ratings.filter((r) => slug(r.restaurant) === key);
  const vals = rs.map((r) => {
    const scores = (r.scores || []).map(Number).filter((n) => n >= 1 && n <= 5);
    return scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : null;
  }).filter((n) => Number.isFinite(n));
  return vals.length ? (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1) : null;
}

function MainTab({ selected, onPress, icon, label }) {
  return (
    <Pressable onPress={onPress} style={[styles.tab, selected && styles.tabOn]}>
      <Text style={styles.tabIcon}>{icon}</Text>
      <Text style={[styles.tabText, selected && styles.tabTextOn]}>{label}</Text>
    </Pressable>
  );
}

function SafetyGate({ lang, setLang, onAccept }) {
  const [checked, setChecked] = useState(false);
  const t = COPY[lang] || COPY.ca;
  return (
    <View style={styles.safetyWrap}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.safetyCard}>
        <Text style={styles.brand}>tastiviu.</Text>
        <Text style={styles.safetyTitle}>{t.safetyTitle}</Text>
        <View style={styles.langRow}>{['ca', 'es', 'eu', 'en', 'fr'].map((l) => (
          <Pressable key={l} onPress={() => setLang(l)} style={[styles.langChip, lang === l && styles.langChipOn]}>
            <Text style={[styles.langText, lang === l && styles.langTextOn]}>{l.toUpperCase()}</Text>
          </Pressable>
        ))}</View>
        <View style={styles.warningBox}>
          <Text style={styles.warningIcon}>⚠️</Text>
          <Text style={styles.warningText}>{t.safetyBody}</Text>
        </View>
        <Pressable onPress={() => setChecked(!checked)} style={styles.checkRow}>
          <View style={[styles.checkBox, checked && styles.checkBoxOn]}><Text style={styles.checkMark}>{checked ? '✓' : ''}</Text></View>
          <Text style={styles.checkText}>{t.safetyCheck}</Text>
        </Pressable>
        <Pressable disabled={!checked} onPress={onAccept} style={[styles.primary, !checked && styles.disabled]}>
          <Text style={styles.primaryText}>{t.enter}</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

function ScannerScreen({ lang, onSendText, onSendBarcode }) {
  const t = COPY[lang] || COPY.ca;
  const cameraRef = useRef(null);
  const [permission, requestPermission] = useCameraPermissions();
  const [mode, setMode] = useState('barcode');
  const [locked, setLocked] = useState(false);
  const [busy, setBusy] = useState(false);
  const [ocrText, setOcrText] = useState('');
  const [product, setProduct] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { if (!permission?.granted) requestPermission(); }, [permission]);

  const lookup = async (code) => {
    setBusy(true); setError(''); setProduct(null);
    try {
      const fields = 'code,product_name,product_name_es,product_name_ca,product_name_en,brands,quantity,ingredients_text,ingredients_text_es,ingredients_text_ca,ingredients_text_en,allergens_tags,traces_tags,image_front_small_url';
      const r = await fetch(`https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(code)}.json?fields=${fields}`);
      const j = await r.json();
      if (!j?.product) setError(t.noProduct);
      else setProduct({ ...j.product, code });
    } catch (e) {
      setError(String(e?.message || e));
    } finally { setBusy(false); }
  };

  const handleBarcode = ({ data }) => {
    if (locked) return;
    setLocked(true);
    lookup(data);
  };

  const ocrUri = async (uri) => {
    setBusy(true); setError(''); setOcrText('');
    try {
      let mod = null;
      try { mod = require('expo-text-extractor'); } catch (_) {}
      if (!mod?.extractTextFromImage) throw new Error(t.ocrUnavailable);
      const lines = await mod.extractTextFromImage(uri);
      const text = Array.isArray(lines) ? lines.join('\n') : String(lines || '');
      if (text.trim().length < 8) throw new Error(t.noText);
      setOcrText(text);
    } catch (e) {
      setError(String(e?.message || e));
    } finally { setBusy(false); }
  };

  const takeLabelPhoto = async () => {
    if (!cameraRef.current) return;
    const photo = await cameraRef.current.takePictureAsync({ quality: 0.8, skipProcessing: false });
    if (photo?.uri) await ocrUri(photo.uri);
  };

  const pickPhoto = async () => {
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.9 });
    if (!r.canceled && r.assets?.[0]?.uri) await ocrUri(r.assets[0].uri);
  };

  if (!permission?.granted) {
    return <View style={styles.center}><Text style={styles.body}>{t.needCamera}</Text><Pressable onPress={requestPermission} style={styles.primary}><Text style={styles.primaryText}>Permís</Text></Pressable></View>;
  }

  return (
    <View style={styles.screen}>
      <View style={styles.nativeHeader}>
        <Text style={styles.nativeTitle}>{t.scan}</Text>
        <View style={styles.segment}>
          <Pressable onPress={() => { setMode('barcode'); setLocked(false); setOcrText(''); setProduct(null); }} style={[styles.segmentBtn, mode === 'barcode' && styles.segmentBtnOn]}><Text style={[styles.segmentTxt, mode === 'barcode' && styles.segmentTxtOn]}>▦ {t.barcode}</Text></Pressable>
          <Pressable onPress={() => { setMode('label'); setLocked(false); setProduct(null); }} style={[styles.segmentBtn, mode === 'label' && styles.segmentBtnOn]}><Text style={[styles.segmentTxt, mode === 'label' && styles.segmentTxtOn]}>Aa {t.label}</Text></Pressable>
        </View>
      </View>
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }}>
        <View style={styles.cameraShell}>
          <CameraView
            ref={cameraRef}
            facing="back"
            style={StyleSheet.absoluteFill}
            onBarcodeScanned={mode === 'barcode' && !locked ? handleBarcode : undefined}
            barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8', 'upc_a', 'upc_e', 'code128', 'code39'] }}
          />
          <View style={styles.cameraOverlay}><View style={mode === 'barcode' ? styles.barcodeFrame : styles.labelFrame} /></View>
        </View>
        <Text style={styles.cameraHint}>{mode === 'barcode' ? t.scanBarcode : t.scanLabel}</Text>
        {mode === 'label' && <View style={styles.actionRow}>
          <Pressable onPress={takeLabelPhoto} disabled={busy} style={styles.primarySmall}><Text style={styles.primaryText}>📷 {t.takePhoto}</Text></Pressable>
          <Pressable onPress={pickPhoto} disabled={busy} style={styles.secondarySmall}><Text style={styles.secondaryText}>🖼 {t.gallery}</Text></Pressable>
        </View>}
        {busy && <View style={styles.loading}><ActivityIndicator color={C.teal} /><Text style={styles.muted}>{mode === 'label' ? t.ocrWorking : 'Open Food Facts…'}</Text></View>}
        {!!error && <View style={styles.errorBox}><Text style={styles.errorText}>{error}</Text></View>}
        {product && <View style={styles.resultCard}>
          <View style={styles.productTop}>
            {!!product.image_front_small_url && <Image source={{ uri: product.image_front_small_url }} style={styles.productImg} />}
            <View style={{ flex: 1 }}><Text style={styles.eyebrow}>{t.product}</Text><Text style={styles.cardTitle}>{chooseProductName(product, product.code)}</Text><Text style={styles.muted}>{product.brands || ''} {product.quantity ? `· ${product.quantity}` : ''}</Text></View>
          </View>
          <Text style={styles.fieldLabel}>{t.ingredients}</Text><Text style={styles.body}>{chooseIngredients(product) || '—'}</Text>
          <Text style={styles.fieldLabel}>{t.allergens}</Text><Text style={styles.body}>{tagLabel(product.allergens_tags) || '—'}</Text>
          <Text style={styles.fieldLabel}>{t.traces}</Text><Text style={styles.body}>{tagLabel(product.traces_tags) || '—'}</Text>
          <Text style={styles.verify}>{t.verify}</Text>
          <Pressable onPress={() => onSendBarcode(product.code)} style={styles.primary}><Text style={styles.primaryText}>{t.analyze}</Text></Pressable>
          <Pressable onPress={() => { setLocked(false); setProduct(null); setError(''); }} style={styles.linkBtn}><Text style={styles.linkText}>{t.again}</Text></Pressable>
        </View>}
        {!!ocrText && <View style={styles.resultCard}>
          <Text style={styles.eyebrow}>OCR · {t.label}</Text>
          <TextInput value={ocrText} onChangeText={setOcrText} multiline style={styles.ocrBox} />
          <Text style={styles.verify}>{t.verify}</Text>
          <Pressable onPress={() => onSendText(ocrText)} style={styles.primary}><Text style={styles.primaryText}>{t.analyze}</Text></Pressable>
        </View>}
      </ScrollView>
    </View>
  );
}

function MapScreen({ lang, webState, onAddPin, onOpenRestaurants }) {
  const t = COPY[lang] || COPY.ca;
  const [region, setRegion] = useState({ latitude: 40.4, longitude: -3.7, latitudeDelta: 8.5, longitudeDelta: 8.5 });
  const [modal, setModal] = useState(false);
  const [draft, setDraft] = useState({ name: '', details: '', type: 'restaurant', lat: '', lng: '', address: '' });
  const [selected, setSelected] = useState(null);
  const [userPos, setUserPos] = useState(null);

  const places = (webState?.places || []).filter((p) => Number.isFinite(Number(p.lat)) && Number.isFinite(Number(p.lng)));
  const ratings = webState?.restaurantRatings || [];

  const locate = async () => {
    const p = await Location.requestForegroundPermissionsAsync();
    if (p.status !== 'granted') return;
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    const next = { latitude: loc.coords.latitude, longitude: loc.coords.longitude, latitudeDelta: 0.05, longitudeDelta: 0.05 };
    setUserPos({ lat: loc.coords.latitude, lng: loc.coords.longitude });
    setRegion(next);
  };

  useEffect(() => { locate(); }, []);

  const save = () => {
    if (!draft.name.trim() || !draft.details.trim()) return;
    onAddPin({ ...draft, id: `native-p-${Date.now()}`, createdAt: new Date().toISOString(), status: 'published', language: lang });
    setModal(false);
  };

  const openGoogle = (p) => {
    const q = encodeURIComponent([p?.name, p?.address].filter(Boolean).join(' ') || 'restaurants');
    Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${q}`);
  };

  const safeJson = (value) => JSON.stringify(value).replace(/</g, '\\u003c');
  const mapHtml = useMemo(() => {
    const payload = places.map((p) => ({
      id: p.id || `${p.name}-${p.lat}-${p.lng}`,
      name: p.name || '', details: p.details || '', address: p.address || '',
      lat: Number(p.lat), lng: Number(p.lng), score: scoreForPlace(p, ratings)
    }));
    const center = userPos || { lat: region.latitude, lng: region.longitude };
    return `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
      <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
      <style>html,body,#map{height:100%;margin:0;background:#eef3ef} .leaflet-control-attribution{font-size:9px} .pin{font:700 12px system-ui;color:#143c3a}</style>
      </head><body><div id="map"></div><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>
      const places=${safeJson(payload)}; const center=${safeJson(center)};
      const map=L.map('map',{zoomControl:true}).setView([center.lat,center.lng], ${userPos ? 14 : 6});
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
      ${userPos ? `L.circleMarker([${userPos.lat},${userPos.lng}],{radius:8,color:'#0F5E59',fillColor:'#0F5E59',fillOpacity:.9}).addTo(map).bindTooltip('La meva ubicació');` : ''}
      places.forEach(p=>{ const m=L.marker([p.lat,p.lng]).addTo(map); m.bindPopup('<div class="pin"><b>'+esc(p.name)+'</b><br>'+esc(p.score?('★ '+p.score+'/5'):p.details)+'</div>'); m.on('click',()=>send({type:'select',id:p.id})); });
      map.on('contextmenu',e=>send({type:'longpress',lat:e.latlng.lat,lng:e.latlng.lng}));
      map.on('dblclick',e=>send({type:'longpress',lat:e.latlng.lat,lng:e.latlng.lng}));
      function send(x){ if(window.ReactNativeWebView) window.ReactNativeWebView.postMessage(JSON.stringify(x)); }
      function esc(s){return String(s||'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]));}
      </script></body></html>`;
  }, [places, ratings, region.latitude, region.longitude, userPos?.lat, userPos?.lng]);

  const onMapMessage = (e) => {
    try {
      const msg = JSON.parse(e.nativeEvent.data || '{}');
      if (msg.type === 'longpress') {
        setDraft({ name: '', details: '', type: 'restaurant', lat: String(msg.lat), lng: String(msg.lng), address: '' });
        setModal(true);
      } else if (msg.type === 'select') {
        const p = places.find((x) => String(x.id || `${x.name}-${x.lat}-${x.lng}`) === String(msg.id));
        if (p) setSelected(p);
      }
    } catch (_) {}
  };

  return (
    <View style={styles.screen}>
      <View style={styles.mapHeader}>
        <View style={{ flex: 1 }}><Text style={styles.nativeTitle}>{t.mapTitle}</Text><Text style={styles.muted}>{t.mapHelp}</Text></View>
        <Pressable onPress={locate} style={styles.roundBtn}><Text>◎</Text></Pressable>
      </View>
      <View style={styles.mapWrap}>
        <WebView key={`${region.latitude.toFixed(4)}-${region.longitude.toFixed(4)}-${places.length}`} source={{ html: mapHtml }} onMessage={onMapMessage} originWhitelist={['*']} javaScriptEnabled domStorageEnabled />
        <View style={styles.mapFloating}>
          <Pressable onPress={() => { const c=userPos || {lat:region.latitude,lng:region.longitude}; setDraft({ name: '', details: '', type: 'restaurant', lat: String(c.lat), lng: String(c.lng), address: '' }); setModal(true); }} style={styles.fab}><Text style={styles.fabText}>＋</Text></Pressable>
        </View>
      </View>
      <View style={styles.mapBottom}>
        <Text style={styles.mapCount}>{places.length} {t.pins}</Text>
        <Text style={styles.mapSmall}>{t.localData} · OpenStreetMap</Text>
        <View style={styles.actionRow}>
          <Pressable onPress={() => openGoogle(selected)} style={styles.secondarySmall}><Text style={styles.secondaryText}>↗ {t.openGoogle}</Text></Pressable>
          <Pressable onPress={onOpenRestaurants} style={styles.primarySmall}><Text style={styles.primaryText}>★ {t.rating}</Text></Pressable>
        </View>
        {!!selected && <View style={styles.selectedPlace}><Text style={styles.cardTitle}>{selected.name}</Text><Text style={styles.body}>{selected.details}</Text>{scoreForPlace(selected, ratings) && <Text style={styles.scoreText}>★ {scoreForPlace(selected, ratings)} / 5</Text>}</View>}
      </View>
      <Modal visible={modal} transparent animationType="slide" onRequestClose={() => setModal(false)}>
        <View style={styles.modalShade}><View style={styles.pinModal}>
          <Text style={styles.cardTitle}>{t.addPin}</Text>
          <TextInput placeholder={t.name} value={draft.name} onChangeText={(v) => setDraft((d) => ({ ...d, name: v }))} style={styles.input} />
          <TextInput placeholder={t.detail} value={draft.details} onChangeText={(v) => setDraft((d) => ({ ...d, details: v }))} style={[styles.input, { minHeight: 110 }]} multiline />
          <View style={styles.actionRow}><Pressable onPress={() => setModal(false)} style={styles.secondarySmall}><Text style={styles.secondaryText}>{t.cancel}</Text></Pressable><Pressable onPress={save} style={styles.primarySmall}><Text style={styles.primaryText}>{t.save}</Text></Pressable></View>
        </View></View>
      </Modal>
    </View>
  );
}

export default function App() {
  const webRef = useRef(null);
  const [tab, setTab] = useState('app');
  const [lang, setLang] = useState('ca');
  const [accepted, setAccepted] = useState(null);
  const [webState, setWebState] = useState({});

  const t = COPY[lang] || COPY.ca;

  useEffect(() => {
    AsyncStorage.getItem('tastiviu-native-safety-v1').then((v) => setAccepted(v === '1'));
    AsyncStorage.getItem('tastiviu-native-lang').then((v) => { if (COPY[v]) setLang(v); });
  }, []);

  useEffect(() => { AsyncStorage.setItem('tastiviu-native-lang', lang); }, [lang]);

  useEffect(() => {
    const sync = async () => {
      const profile = (webState?.profiles || []).find((p) => p.id === webState?.activeProfileId) || webState?.profiles?.[0];
      const meds = profile?.medications || [];
      if (!meds.length) return;
      const hash = JSON.stringify(meds.map((m) => [m.id, m.name, m.expiry, m.remindBefore]));
      const old = await AsyncStorage.getItem('tastiviu-meds-notification-hash');
      if (old === hash) return;
      const perm = await Notifications.requestPermissionsAsync();
      if (perm.status !== 'granted') return;
      await Notifications.cancelAllScheduledNotificationsAsync();
      for (const m of meds) {
        if (!m.expiry) continue;
        const days = Number(m.remindBefore ?? 30);
        const date = new Date(`${m.expiry}T09:00:00`);
        date.setDate(date.getDate() - (Number.isFinite(days) ? days : 30));
        if (date <= new Date()) continue;
        await Notifications.scheduleNotificationAsync({
          content: { title: 'TASTIVIU · Medicació', body: `${m.name || 'Medicació'}: caduca el ${m.expiry}. Revisa la renovació.` },
          trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date },
        });
      }
      await AsyncStorage.setItem('tastiviu-meds-notification-hash', hash);
    };
    sync().catch(() => {});
  }, [webState]);

  const preloadJS = useMemo(() => `
    (function(){
      try {
        var current = JSON.parse(localStorage.getItem('tastiviu-v4') || '{}');
        current.lang = ${JSON.stringify(lang)};
        localStorage.setItem('tastiviu-v4', JSON.stringify(current));
        if (${accepted ? 'true' : 'false'}) localStorage.setItem('tastiviu-safety-v1','1');
        var apiBase=${JSON.stringify(API_BASE)};
        if(apiBase){
          var originalFetch=window.fetch.bind(window);
          window.fetch=function(input,init){
            if(typeof input==='string' && input.indexOf('/api/')===0) input=apiBase.replace(/\/$/,'')+input;
            return originalFetch(input,init);
          };
        }
      } catch(e){}
      true;
    })();
  `, [lang, accepted]);

  const bridgeJS = useMemo(() => `
    (function(){
      try {
        if (${accepted ? 'true' : 'false'}) {
          var cb=document.querySelector('#safetyAcceptCheck');
          if(cb){ cb.checked=true; cb.dispatchEvent(new Event('change',{bubbles:true})); var b=document.querySelector('[data-accept-safety]'); if(b){b.disabled=false;b.click();} }
        }
        function post(){
          try { window.ReactNativeWebView.postMessage(JSON.stringify({type:'STATE',payload:JSON.parse(localStorage.getItem('tastiviu-v4')||'{}')})); } catch(e){}
        }
        post(); setInterval(post, 1800);
      } catch(e){}
      true;
    })();
  `, [accepted]);

  const goWebScannerWithText = (text) => {
    const js = `
      (function(){
        try {
          var nav=document.querySelector('[data-page="scan"]'); if(nav) nav.click();
          setTimeout(function(){ var ta=document.querySelector('#scannerText'); if(ta){ ta.value=${JSON.stringify(text)}; ta.dispatchEvent(new Event('input',{bubbles:true})); var b=document.querySelector('[data-analyze]'); if(b)b.click(); } },220);
        }catch(e){}
        true;
      })();`;
    webRef.current?.injectJavaScript(js); setTab('app');
  };

  const goWebProductWithBarcode = (code) => {
    const js = `
      (function(){
        try {
          var nav=document.querySelector('[data-page="products"]'); if(nav) nav.click();
          setTimeout(function(){ var q=document.querySelector('#productQuery'); if(q){ q.value=${JSON.stringify(code)}; q.dispatchEvent(new Event('input',{bubbles:true})); var b=document.querySelector('[data-product-search]'); if(b)b.click(); } },220);
        }catch(e){}
        true;
      })();`;
    webRef.current?.injectJavaScript(js); setTab('app');
  };

  const addPin = async (pin) => {
    if (API_BASE) {
      try {
        const r = await fetch(`${API_BASE.replace(/\/$/, '')}/api/places`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(pin) });
        if (r.ok) {
          webRef.current?.reload();
          setWebState((s) => ({ ...s, places: [pin, ...(s.places || [])] }));
          return;
        }
      } catch (_) {}
    }
    const js = `
      (function(){
        try {
          var s=JSON.parse(localStorage.getItem('tastiviu-v4')||'{}');
          s.places=Array.isArray(s.places)?s.places:[]; s.places.unshift(${JSON.stringify(pin)});
          localStorage.setItem('tastiviu-v4',JSON.stringify(s)); location.reload();
        }catch(e){}
        true;
      })();`;
    webRef.current?.injectJavaScript(js);
    setWebState((s) => ({ ...s, places: [pin, ...(s.places || [])] }));
  };

  const openRestaurants = () => {
    webRef.current?.injectJavaScript(`(function(){try{var n=document.querySelector('[data-page="restaurants"]');if(n)n.click();}catch(e){}true;})();`);
    setTab('app');
  };

  if (accepted === null) return <View style={styles.center}><ActivityIndicator color={C.teal} /></View>;
  if (!accepted) return <SafetyGate lang={lang} setLang={setLang} onAccept={async () => { await AsyncStorage.setItem('tastiviu-native-safety-v1', '1'); setAccepted(true); }} />;

  return (
    <View style={styles.root}>
      <StatusBar style="dark" />
      <View style={[styles.layer, tab !== 'app' && styles.hidden]}>
        <WebView
          ref={webRef}
          source={{ html: TASTIVIU_HTML, baseUrl: 'https://tastiviu.local/' }}
          originWhitelist={['*']}
          javaScriptEnabled
          domStorageEnabled
          allowFileAccess
          geolocationEnabled
          mixedContentMode="always"
          injectedJavaScriptBeforeContentLoaded={preloadJS}
          injectedJavaScript={bridgeJS}
          onMessage={(e) => {
            try {
              const m = JSON.parse(e.nativeEvent.data);
              if (m.type === 'STATE' && m.payload) {
                setWebState(m.payload);
                if (COPY[m.payload.lang]) setLang(m.payload.lang);
              }
            } catch (_) {}
          }}
          onShouldStartLoadWithRequest={(req) => {
            if (req.url.startsWith('https://tastiviu.local') || req.url === 'about:blank') return true;
            if (req.navigationType === 'click') { Linking.openURL(req.url).catch(() => {}); return false; }
            return true;
          }}
          style={styles.web}
        />
      </View>
      <View style={[styles.layer, tab !== 'scan' && styles.hidden]}><ScannerScreen lang={lang} onSendText={goWebScannerWithText} onSendBarcode={goWebProductWithBarcode} /></View>
      <View style={[styles.layer, tab !== 'map' && styles.hidden]}><MapScreen lang={lang} webState={webState} onAddPin={addPin} onOpenRestaurants={openRestaurants} /></View>
      <View style={styles.bottomBar}>
        <MainTab selected={tab === 'app'} onPress={() => setTab('app')} icon="⌂" label={t.app} />
        <MainTab selected={tab === 'scan'} onPress={() => setTab('scan')} icon="▦" label={t.scan} />
        <MainTab selected={tab === 'map'} onPress={() => setTab('map')} icon="⌖" label={t.map} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream, paddingTop: Platform.OS === 'android' ? 24 : 0 },
  layer: { ...StyleSheet.absoluteFillObject, bottom: 76, backgroundColor: C.cream },
  hidden: { display: 'none' },
  web: { flex: 1, backgroundColor: C.cream },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 14, padding: 24, backgroundColor: C.cream },
  bottomBar: { position: 'absolute', left: 12, right: 12, bottom: 10, height: 64, borderRadius: 22, backgroundColor: C.ink, flexDirection: 'row', padding: 6, shadowColor: '#000', shadowOpacity: 0.16, shadowRadius: 20, elevation: 12 },
  tab: { flex: 1, borderRadius: 17, alignItems: 'center', justifyContent: 'center', gap: 2 }, tabOn: { backgroundColor: '#FFFFFF18' }, tabIcon: { color: 'white', fontSize: 19, fontWeight: '800' }, tabText: { color: '#CFE1DD', fontSize: 11, fontWeight: '700' }, tabTextOn: { color: 'white' },
  safetyWrap: { flex: 1, backgroundColor: C.cream }, safetyCard: { padding: 24, paddingTop: 64, paddingBottom: 40 }, brand: { fontSize: 30, fontWeight: '900', color: C.ink, letterSpacing: -1.2 }, safetyTitle: { fontSize: 30, lineHeight: 34, fontWeight: '900', color: C.ink, marginTop: 30 },
  langRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 18 }, langChip: { paddingHorizontal: 13, paddingVertical: 9, borderRadius: 999, backgroundColor: C.paper, borderWidth: 1, borderColor: C.line }, langChipOn: { backgroundColor: C.ink, borderColor: C.ink }, langText: { color: C.ink, fontWeight: '800' }, langTextOn: { color: 'white' },
  warningBox: { backgroundColor: '#FFF3E8', borderRadius: 22, padding: 18, marginTop: 24, borderWidth: 1, borderColor: '#F0C6A3' }, warningIcon: { fontSize: 26, marginBottom: 8 }, warningText: { color: '#603E24', fontSize: 15, lineHeight: 23, fontWeight: '600' }, checkRow: { flexDirection: 'row', gap: 12, marginVertical: 22, alignItems: 'flex-start' }, checkBox: { width: 24, height: 24, borderRadius: 7, borderWidth: 2, borderColor: C.teal, alignItems: 'center', justifyContent: 'center', marginTop: 2 }, checkBoxOn: { backgroundColor: C.teal }, checkMark: { color: 'white', fontWeight: '900' }, checkText: { flex: 1, color: C.ink, fontSize: 14, lineHeight: 21, fontWeight: '600' },
  primary: { backgroundColor: C.coral, borderRadius: 16, paddingHorizontal: 18, paddingVertical: 15, alignItems: 'center', marginTop: 12 }, primaryText: { color: 'white', fontWeight: '900', fontSize: 15 }, disabled: { opacity: 0.35 },
  screen: { flex: 1, backgroundColor: C.cream }, nativeHeader: { paddingHorizontal: 18, paddingTop: 14, paddingBottom: 10 }, nativeTitle: { fontSize: 28, fontWeight: '900', color: C.ink, letterSpacing: -0.8 }, segment: { flexDirection: 'row', marginTop: 12, backgroundColor: C.sage, padding: 4, borderRadius: 14 }, segmentBtn: { flex: 1, paddingVertical: 10, borderRadius: 11, alignItems: 'center' }, segmentBtnOn: { backgroundColor: C.paper }, segmentTxt: { color: C.muted, fontWeight: '800' }, segmentTxtOn: { color: C.ink },
  cameraShell: { height: 330, marginHorizontal: 18, borderRadius: 26, overflow: 'hidden', backgroundColor: '#111' }, cameraOverlay: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' }, barcodeFrame: { width: '78%', height: 120, borderWidth: 3, borderColor: 'white', borderRadius: 18, backgroundColor: '#FFFFFF08' }, labelFrame: { width: '84%', height: 220, borderWidth: 3, borderColor: 'white', borderRadius: 18, backgroundColor: '#FFFFFF08' }, cameraHint: { textAlign: 'center', color: C.muted, fontWeight: '700', marginVertical: 12 },
  actionRow: { flexDirection: 'row', gap: 10, marginTop: 12, flexWrap: 'wrap' }, primarySmall: { flexGrow: 1, backgroundColor: C.coral, paddingHorizontal: 15, paddingVertical: 12, borderRadius: 14, alignItems: 'center' }, secondarySmall: { flexGrow: 1, backgroundColor: C.paper, paddingHorizontal: 15, paddingVertical: 12, borderRadius: 14, alignItems: 'center', borderWidth: 1, borderColor: C.line }, secondaryText: { color: C.ink, fontWeight: '800' }, loading: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 10, margin: 18 }, muted: { color: C.muted, fontSize: 13, lineHeight: 18 }, errorBox: { backgroundColor: '#FCEAE7', margin: 18, padding: 14, borderRadius: 14 }, errorText: { color: C.danger, fontWeight: '700' },
  resultCard: { backgroundColor: C.paper, margin: 18, marginTop: 8, borderRadius: 24, padding: 18, borderWidth: 1, borderColor: C.line }, productTop: { flexDirection: 'row', gap: 14, alignItems: 'center' }, productImg: { width: 78, height: 78, borderRadius: 16, backgroundColor: C.sage }, eyebrow: { color: C.teal, fontWeight: '900', fontSize: 11, letterSpacing: 1.1, textTransform: 'uppercase' }, cardTitle: { color: C.ink, fontWeight: '900', fontSize: 20, lineHeight: 24, marginTop: 4 }, fieldLabel: { color: C.teal, fontWeight: '900', fontSize: 12, marginTop: 16, marginBottom: 5, textTransform: 'uppercase' }, body: { color: C.ink, fontSize: 14, lineHeight: 21 }, verify: { backgroundColor: C.sage, color: C.ink, fontWeight: '700', padding: 12, borderRadius: 12, marginTop: 16 }, linkBtn: { alignItems: 'center', padding: 13 }, linkText: { color: C.teal, fontWeight: '800' }, ocrBox: { minHeight: 180, backgroundColor: C.cream, borderRadius: 14, padding: 12, marginTop: 10, textAlignVertical: 'top', color: C.ink },
  mapHeader: { paddingHorizontal: 18, paddingTop: 14, paddingBottom: 10, flexDirection: 'row', gap: 12, alignItems: 'center' }, roundBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: C.paper, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: C.line }, mapWrap: { height: '55%', marginHorizontal: 14, borderRadius: 24, overflow: 'hidden', borderWidth: 1, borderColor: C.line }, mapFloating: { position: 'absolute', right: 14, bottom: 14 }, fab: { width: 54, height: 54, borderRadius: 27, backgroundColor: C.coral, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: 0.18, shadowRadius: 10, elevation: 5 }, fabText: { color: 'white', fontSize: 30, lineHeight: 32 }, mapBottom: { padding: 18 }, mapCount: { color: C.ink, fontSize: 18, fontWeight: '900' }, mapSmall: { color: C.muted, fontSize: 12, lineHeight: 17, marginTop: 3 }, selectedPlace: { backgroundColor: C.paper, borderRadius: 18, padding: 14, marginTop: 12, borderWidth: 1, borderColor: C.line }, scoreText: { color: C.coral, fontWeight: '900', marginTop: 8 },
  modalShade: { flex: 1, backgroundColor: '#0007', justifyContent: 'flex-end' }, pinModal: { backgroundColor: C.cream, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 22, paddingBottom: 34 }, input: { backgroundColor: C.paper, borderWidth: 1, borderColor: C.line, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, color: C.ink, marginTop: 12, textAlignVertical: 'top' },
});
