# TASTIVIU Android

La mateixa base genera l’app Android.

## Per provar avui

- Opció ràpida: `npx expo start` + Expo Go.
- Per provar també l’OCR natiu: `npx eas build --platform android --profile development` o `preview`.
- `preview` genera un APK instal·lable que pots enviar als familiars.

## Mapa

En una build pròpia d’Android, configura `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY` abans de compilar.
