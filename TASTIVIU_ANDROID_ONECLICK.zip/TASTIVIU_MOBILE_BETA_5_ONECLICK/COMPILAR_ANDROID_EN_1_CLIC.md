# TASTIVIU — APK Android amb un clic

Aquest projecte porta una automatització de GitHub que compila un APK instal·lable sense Android Studio, sense configurar Google Maps i sense EAS.

## El mínim imprescindible

1. Crear/usar un compte de GitHub.
2. Pujar aquesta carpeta a un repositori privat.
3. Entrar a **Actions** → **Build TASTIVIU Android APK** → **Run workflow**.
4. Quan acabi, descarregar l'artefacte **TASTIVIU-BETA-ANDROID**.
5. Descomprimir-lo i enviar `TASTIVIU-BETA-ANDROID.apk` al telèfon Android.
6. Al mòbil, permetre temporalment “instal·lar apps desconegudes” per a l'app que obre l'APK i instal·lar-lo.

## Què porta aquesta beta

- Càmera i lector de codis EAN/UPC.
- Consulta de productes Open Food Facts.
- OCR natiu d'etiquetes (quan el mòdul és compatible amb el dispositiu/build).
- Mapa dins de l'app amb OpenStreetMap, ubicació i xinxetes, sense clau de Google Maps.
- Accés a Google Maps per buscar l'establiment seleccionat.
- Notificacions locals de medicació/caducitat.
- TASTIVIU completa integrada.

## Important

Aquesta és una beta familiar. La informació d'al·lèrgens és orientativa: cal revisar sempre l'etiqueta actual del producte i seguir el pla mèdic individual.

Perquè les xinxetes, puntuacions i fòrum siguin compartits entre diversos telèfons cal publicar el backend i definir `EXPO_PUBLIC_API_BASE_URL`.
