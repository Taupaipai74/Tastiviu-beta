-- Production-oriented shared/community schema for TASTIVIU.
-- Use row-level security, authentication and moderation policies in production.

create table if not exists restaurant_reviews (
  id uuid primary key,
  author_id uuid,
  restaurant_name text not null,
  place_provider text,
  place_id text,
  city text,
  visit_date date,
  scores jsonb not null,
  comment text,
  language text,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists restaurant_reviews_place_idx on restaurant_reviews(place_id, created_at desc);

create table if not exists community_places (
  id uuid primary key,
  author_id uuid,
  name text not null,
  place_type text not null,
  address text,
  city text,
  latitude double precision,
  longitude double precision,
  details text not null,
  language text,
  provider text,
  provider_place_id text,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists community_places_geo_idx on community_places(latitude, longitude);
create index if not exists community_places_provider_idx on community_places(provider, provider_place_id);

create table if not exists community_posts (
  id uuid primary key,
  author_id uuid,
  nickname text,
  category text not null,
  title text not null,
  body text not null,
  language text,
  empathy_count integer not null default 0,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists community_posts_created_idx on community_posts(created_at desc);

create table if not exists community_post_reactions (
  post_id uuid not null references community_posts(id) on delete cascade,
  actor_id uuid not null,
  reaction text not null default 'empathy',
  created_at timestamptz not null default now(),
  primary key(post_id, actor_id, reaction)
);

create table if not exists reports (
  id uuid primary key,
  reporter_id uuid,
  entity_type text not null,
  entity_id uuid,
  reason text not null,
  details text,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create table if not exists sponsors (
  id uuid primary key,
  name text not null,
  website text,
  tier text,
  disclosure text not null,
  starts_at date,
  ends_at date,
  active boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists moderation_events (
  id uuid primary key,
  moderator_id uuid,
  entity_type text not null,
  entity_id uuid,
  action text not null,
  reason text,
  created_at timestamptz not null default now()
);

-- Personal medication data. In production this table must be private to the
-- authenticated profile owner/authorised caregiver and protected with RLS.
create table if not exists profile_medications (
  id uuid primary key,
  profile_id uuid not null,
  name text not null,
  prescribed_dose text,
  instructions text,
  storage_location text,
  expiry_date date,
  reminder_days integer not null default 30,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists profile_medications_expiry_idx on profile_medications(profile_id, expiry_date);
