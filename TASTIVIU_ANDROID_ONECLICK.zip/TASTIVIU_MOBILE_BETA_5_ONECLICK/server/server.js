'use strict';
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const ROOT=__dirname,DATA=path.join(ROOT,'data');
const FILES={reviews:path.join(DATA,'reviews.json'),places:path.join(DATA,'places.json'),posts:path.join(DATA,'posts.json')};
const PORT=Number(process.env.PORT||8080);
if(!fs.existsSync(DATA))fs.mkdirSync(DATA,{recursive:true});
for(const f of Object.values(FILES))if(!fs.existsSync(f))fs.writeFileSync(f,'[]');
const mime={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webmanifest':'application/manifest+json'};
const rates=new Map();
function headers(res,type='application/json; charset=utf-8'){res.setHeader('Content-Type',type);res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Headers','Content-Type');res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('Permissions-Policy','camera=(self), geolocation=(self)');res.setHeader('X-Frame-Options','SAMEORIGIN')}
function json(res,status,obj){headers(res);res.statusCode=status;res.end(JSON.stringify(obj))}
function read(file){try{return JSON.parse(fs.readFileSync(file,'utf8'))}catch{return[]}}
function write(file,x){fs.writeFileSync(file,JSON.stringify(x,null,2))}
function clientIp(req){return (req.headers['x-forwarded-for']||req.socket.remoteAddress||'').split(',')[0].trim()}
function allowedPost(ip){const now=Date.now(),windowMs=60*60*1000,limit=30;let x=rates.get(ip)||[];x=x.filter(t=>now-t<windowMs);if(x.length>=limit)return false;x.push(now);rates.set(ip,x);return true}
function body(req,max=50000){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>max){reject(new Error('too-large'));req.destroy()}});req.on('end',()=>{try{resolve(JSON.parse(s||'{}'))}catch{reject(new Error('bad-json'))}});req.on('error',reject)})}
function clean(s,max){return String(s||'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s{3,}/g,'  ').trim().slice(0,max)}
function finite(v,min,max){const n=Number(v);return Number.isFinite(n)&&n>=min&&n<=max?n:null}
function validateReview(v){const scores=Array.isArray(v.scores)?v.scores.slice(0,5).map(x=>x==null?null:Number(x)):[];while(scores.length<5)scores.push(null);if(!v.restaurant||clean(v.restaurant,120).length<2)return null;if(scores.some(x=>x!==null&&(!Number.isInteger(x)||x<1||x>5)))return null;return{id:crypto.randomUUID(),restaurant:clean(v.restaurant,120),city:clean(v.city,100),visitDate:/^\d{4}-\d{2}-\d{2}$/.test(v.visitDate||'')?v.visitDate:'',scores,comment:clean(v.comment,900),language:clean(v.language,8),createdAt:new Date().toISOString(),status:'published'}}
function validatePlace(v){const name=clean(v.name,120),details=clean(v.details,1000);if(name.length<2||details.length<3)return null;const types=new Set(['restaurant','icecream','bakery','cafe','supermarket','hotel','other']);return{id:crypto.randomUUID(),name,type:types.has(v.type)?v.type:'other',address:clean(v.address,180),details,lat:finite(v.lat,-90,90),lng:finite(v.lng,-180,180),language:clean(v.language,8),createdAt:new Date().toISOString(),status:'published'}}
function validatePost(v){const title=clean(v.title,120),txt=clean(v.body,1500);if(title.length<2||txt.length<3)return null;const cats=new Set(['vent','discovery','restaurant','school','travel']);return{id:crypto.randomUUID(),category:cats.has(v.category)?v.category:'vent',nickname:clean(v.nickname,40)||'Anònim/a',title,body:txt,language:clean(v.language,8),empathy:0,createdAt:new Date().toISOString(),status:'published'}}
function serve(req,res){let pathname;try{pathname=decodeURIComponent(new URL(req.url,'http://x').pathname)}catch{return json(res,400,{error:'bad-url'})}if(pathname==='/')pathname='/index.html';const safe=path.normalize(pathname).replace(/^(\.\.(\/|\\|$))+/, '');const file=path.join(ROOT,safe);if(!file.startsWith(ROOT))return json(res,403,{error:'forbidden'});fs.stat(file,(err,st)=>{if(err||!st.isFile())return json(res,404,{error:'not-found'});headers(res,mime[path.extname(file)]||'application/octet-stream');res.statusCode=200;if(req.method==='HEAD')return res.end();fs.createReadStream(file).pipe(res)})}
const server=http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://x');
 if(req.method==='OPTIONS'){headers(res);res.statusCode=204;return res.end()}
 if(req.method==='GET'&&u.pathname==='/api/health')return json(res,200,{ok:true,service:'TASTIVIU community API',version:'3'});
 if(req.method==='GET'&&u.pathname==='/api/reviews'){const items=read(FILES.reviews).filter(x=>x.status==='published').sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,400);return json(res,200,{reviews:items})}
 if(req.method==='GET'&&u.pathname==='/api/places'){const items=read(FILES.places).filter(x=>x.status==='published').sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,400);return json(res,200,{places:items})}
 if(req.method==='GET'&&u.pathname==='/api/posts'){const items=read(FILES.posts).filter(x=>x.status==='published').sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,300);return json(res,200,{posts:items})}
 if(req.method==='POST'&&['/api/reviews','/api/places','/api/posts','/api/posts/empathy'].includes(u.pathname)){
   const ip=clientIp(req);if(!allowedPost(ip))return json(res,429,{error:'rate-limit'});
   try{
    const raw=await body(req);
    if(u.pathname==='/api/reviews'){const v=validateReview(raw);if(!v)return json(res,400,{error:'invalid-review'});const items=read(FILES.reviews);items.push(v);write(FILES.reviews,items);return json(res,201,{ok:true,review:v})}
    if(u.pathname==='/api/places'){const v=validatePlace(raw);if(!v)return json(res,400,{error:'invalid-place'});const items=read(FILES.places);items.push(v);write(FILES.places,items);return json(res,201,{ok:true,place:v})}
    if(u.pathname==='/api/posts'){const v=validatePost(raw);if(!v)return json(res,400,{error:'invalid-post'});const items=read(FILES.posts);items.push(v);write(FILES.posts,items);return json(res,201,{ok:true,post:v})}
    if(u.pathname==='/api/posts/empathy'){const id=clean(raw.id,80);const items=read(FILES.posts),p=items.find(x=>x.id===id&&x.status==='published');if(!p)return json(res,404,{error:'not-found'});p.empathy=Math.min(999999,Number(p.empathy||0)+1);write(FILES.posts,items);return json(res,200,{ok:true,empathy:p.empathy})}
   }catch(e){return json(res,e.message==='too-large'?413:400,{error:e.message})}
 }
 if(req.method==='GET'||req.method==='HEAD')return serve(req,res);return json(res,405,{error:'method-not-allowed'});
});
server.listen(PORT,()=>console.log(`TASTIVIU http://localhost:${PORT}`));
