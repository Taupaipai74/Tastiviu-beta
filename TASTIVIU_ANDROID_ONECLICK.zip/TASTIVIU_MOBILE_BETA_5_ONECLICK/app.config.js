const googleMapsKey = process.env.EXPO_PUBLIC_GOOGLE_MAPS_API_KEY || '';

module.exports = {
  expo: {
    name: 'TASTIVIU',
    slug: 'tastiviu-mobile-beta',
    version: '5.0.0',
    orientation: 'portrait',
    userInterfaceStyle: 'light',
    scheme: 'tastiviu',
    ios: {
      supportsTablet: true,
      bundleIdentifier: 'org.tastiviu.beta',
      infoPlist: {
        NSCameraUsageDescription: 'TASTIVIU necessita la càmera per llegir etiquetes i codis de barres.',
        NSLocationWhenInUseUsageDescription: 'TASTIVIU utilitza la ubicació per mostrar establiments i xinxetes properes.',
        NSPhotoLibraryUsageDescription: 'TASTIVIU pot llegir una fotografia d’una etiqueta que triïs.'
      }
    },
    android: {
      package: 'org.tastiviu.beta',
      permissions: ['CAMERA', 'ACCESS_COARSE_LOCATION', 'ACCESS_FINE_LOCATION', 'POST_NOTIFICATIONS'],
      config: googleMapsKey ? { googleMaps: { apiKey: googleMapsKey } } : {}
    },
    plugins: [
      ['expo-camera', {
        cameraPermission: 'Permet que TASTIVIU utilitzi la càmera per escanejar etiquetes i codis de barres.',
        barcodeScannerEnabled: true,
        recordAudioAndroid: false
      }],
      ['expo-location', {
        locationWhenInUsePermission: 'Permet que TASTIVIU utilitzi la ubicació per mostrar establiments propers.'
      }],
      ['expo-notifications', {}]
    ],
    extra: {
      apiBaseUrl: process.env.EXPO_PUBLIC_API_BASE_URL || '',
      googleMapsConfigured: Boolean(googleMapsKey)
    }
  }
};
