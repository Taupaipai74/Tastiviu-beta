# TASTIVIU iPhone / iOS

La mateixa base genera l’app iPhone.

## Per provar avui

- `npx expo start` + Expo Go permet provar gran part de l’app.
- Per OCR natiu i una prova semblant a producció: `npx eas build --platform ios --profile development` o `preview`.
- Per convidar família sense connectar el mòbil al teu ordinador, el canal ideal després és TestFlight.

## Signatura

Apple exigeix signatura per instal·lar una app pròpia en un iPhone. EAS pot gestionar certificats i provisionament quan es connecta un compte Apple Developer.
