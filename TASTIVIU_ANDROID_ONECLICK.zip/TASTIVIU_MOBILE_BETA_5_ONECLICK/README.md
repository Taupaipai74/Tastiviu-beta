# TASTIVIU Mobile Beta 5.0 — Android + iOS

Aquesta és la primera versió **mòbil nativa** de TASTIVIU. Un únic projecte genera Android i iPhone.

## Què funciona

- Totes les funcions de TASTIVIU PRO 4.2 dins de la pestanya principal: perfil, al·lèrgies/traces, Descobreix, productes Open Food Facts, medicació, escola, targeta de viatge, enciclopèdia, consells, comunitat, SOS, alertes i patrocinadors.
- Escàner natiu de codis EAN/UPC amb càmera i consulta real a Open Food Facts.
- OCR natiu d’etiquetes: Google ML Kit a Android i Apple Vision a iOS mitjançant `expo-text-extractor`.
- El text OCR s’envia a l’analitzador TASTIVIU existent i es compara amb el perfil actiu.
- Mapa natiu amb ubicació, xinxetes de la comunitat, comentaris i puntuació TASTIVIU.
- Les xinxetes creades des del mapa natiu també es guarden a TASTIVIU.
- Avisos locals de caducitat de medicació: la informació introduïda a TASTIVIU programa notificacions natives.
- Avís de seguretat obligatori abans de començar.
- Català, castellà, euskera, anglès i francès.

## Arquitectura de beta

La capa completa de producte que ja existeix (TASTIVIU 4.2) s’executa dins d’un WebView local, sense dependre d’un servidor per obrir l’app. L’escàner, el mapa, la càmera, la ubicació i les notificacions són natives. Això permet provar totes les funcions ara sense reescriure de zero cada pantalla. A mesura que la beta es valida, les pantalles es poden migrar progressivament a React Native pur.

## Requisits

- Node 22 (Expo SDK 58 usa Node 22.13.x com a línia recomanada)
- Android Studio per compilació Android local o EAS Build
- Xcode/macOS per compilació iOS local, o EAS Build
- Compte Expo per builds EAS
- Per instal·lar una build iOS en dispositius reals cal signatura d’Apple.

## Instal·lació

```bash
npm install
npx expo install --fix
npx expo-doctor
```

### Prova ràpida

```bash
npx expo start
```

El mapa, la càmera i el codi de barres es poden provar en Expo Go. L’OCR `expo-text-extractor` és un mòdul natiu i necessita una development build o una build instal·lable.

## Android APK instal·lable

1. Crea un projecte a Google Cloud i habilita Maps SDK for Android.
2. Copia `.env.example` a `.env` i posa `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY=...`.
3. Inicia sessió a Expo:

```bash
npx eas login
```

4. Genera un APK privat:

```bash
npx eas build --platform android --profile preview
```

EAS retornarà un enllaç privat per instal·lar l’APK als Android de la família.

## iPhone instal·lable

Per a iPhone hi ha dues opcions:

### Development / internal build

```bash
npx eas build --platform ios --profile preview
```

Cal un compte Apple Developer i registrar els dispositius quan EAS ho demani.

### TestFlight

Quan la beta estigui preparada, genera una build de producció i puja-la a App Store Connect / TestFlight.

## Mapa

- `react-native-maps` utilitza Google Maps a Android i Apple Maps (o Google Maps) a iOS.
- En Expo Go no cal configuració extra per provar `react-native-maps`.
- Un APK/AAB Android propi necessita una clau de Google Maps configurada a `.env`.
- Les xinxetes TASTIVIU funcionen sense Google Places. Per importar/mostrar l’inventari de Google Places dins l’app cal una clau de Places API i complir les seves condicions.

## Backend compartit

La carpeta `server/` inclou el backend de la beta anterior per ressenyes, xinxetes i fòrum. Per a una beta familiar real recomanem desplegar-lo en HTTPS o migrar-lo a Supabase/PostgreSQL.

El següent pas recomanat és Supabase amb:

- `users`
- `profiles`
- `profile_allergies`
- `medications`
- `products` + `product_versions`
- `places`
- `restaurant_reviews`
- `forum_posts`
- `alerts`
- `audit_logs`

amb Row Level Security per a les dades privades.

## Seguretat

TASTIVIU és orientatiu. L’usuari ha de revisar sempre l’etiqueta actual, ja que receptes i processos poden canviar. L’OCR i les dades externes poden ser incomplets. La versió beta no s’ha de presentar com una certificació de seguretat alimentària ni com un substitut del pla mèdic.

## Build Android sense Google Maps API key

Aquesta variant inclou `.github/workflows/build-android-apk.yml`. El mapa de la beta usa OpenStreetMap dins d'un WebView i no necessita una Google Maps API key. Vegeu `COMPILAR_ANDROID_EN_1_CLIC.md`.
